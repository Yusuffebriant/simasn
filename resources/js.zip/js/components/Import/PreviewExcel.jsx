function PreviewExcel({
    headers,
    preview,
    next,
    back
}) {


    return (

        <div>


            <h2 className="
                text-2xl
                font-bold
                mb-5
            ">
                Preview Data Excel
            </h2>



            <div className="
                overflow-x-auto
                border
            ">


                <table className="
                    min-w-max
                    border-collapse
                ">


                    <thead>


                        <tr>


                        {
                            headers.map((header,index)=>(

                                <th

                                    key={index}

                                    className="
                                        border
                                        px-4
                                        py-3
                                        bg-gray-100
                                        font-bold
                                        whitespace-nowrap
                                    "

                                >

                                    {header || "-"}

                                </th>


                            ))
                        }


                        </tr>


                    </thead>




                    <tbody>


                    {
                        preview.map((row,rowIndex)=>(


                            <tr key={rowIndex}>


                            {
                                headers.map((_,colIndex)=>(

                                    <td

                                    key={colIndex}

                                    className="
                                        border
                                        px-4
                                        py-2
                                        whitespace-nowrap
                                    "

                                    >

                                    {
                                        row[colIndex] ?? "-"
                                    }


                                    </td>


                                ))
                            }


                            </tr>


                        ))
                    }


                    </tbody>


                </table>



            </div>





            <div className="
                mt-6
                flex
                gap-3
            ">


                <button

                onClick={back}

                className="
                    px-5
                    py-2
                    bg-gray-300
                    rounded
                "

                >

                    Kembali

                </button>



                <button

                onClick={next}

                className="
                    px-5
                    py-2
                    bg-[#006A4E]
                    text-white
                    rounded
                "

                >

                    Lanjut Mapping

                </button>



            </div>


        </div>

    )

}


export default PreviewExcel;