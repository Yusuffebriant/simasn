import { useState } from "react";

import UploadExcel from "./UploadExcel";
import PreviewExcel from "./PreviewExcel";
import ColumnMapping from "./ColumnMapping";
import ImportProgress from "./ImportProgress";
import ImportResult from "./ImportResult";



function ImportWizard(){


    const [step,setStep] = useState(1);



    const [file,setFile] = useState(null);


    const [headers,setHeaders] = useState([]);


    const [preview,setPreview] = useState([]);



    const [mapping,setMapping] = useState({});





    return (

        <div>


            <h2 className="
                text-2xl
                font-bold
                mb-6
            ">

                Import Data ASN

            </h2>




            {/* STEP BAR */}

            <div className="
                flex
                gap-3
                mb-8
            ">


            {
                [

                    "Upload",
                    "Preview",
                    "Mapping",
                    "Import",
                    "Selesai"

                ].map((item,index)=>(


                    <div

                    key={item}

                    className={`
                        px-4
                        py-2
                        rounded-lg

                        ${
                            step === index+1

                            ?

                            "bg-[#006A4E] text-white"

                            :

                            "bg-gray-200"

                        }

                    `}

                    >

                    {index+1}. {item}


                    </div>


                ))

            }


            </div>







            {
                step===1 &&


                <UploadExcel

                    setFile={setFile}

                    setHeaders={setHeaders}

                    setPreview={setPreview}

                    next={()=>setStep(2)}

                />


            }






            {
                step===2 &&


                <PreviewExcel

                    headers={headers}

                    preview={preview}

                    next={()=>setStep(3)}

                    back={()=>setStep(1)}

                />


            }







            {
                step===3 &&


                <ColumnMapping

                    headers={headers}

                    mapping={mapping}

                    setMapping={setMapping}

                    next={()=>setStep(4)}

                    back={()=>setStep(2)}

                />


            }







            {
                step===4 &&


                <ImportProgress

                    file={file}

                    mapping={mapping}

                    next={()=>setStep(5)}

                />


            }







            {
                step===5 &&


                <ImportResult/>

            }





        </div>


    );


}


export default ImportWizard;