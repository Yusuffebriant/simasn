function ImportProgress({next}){


return (

<div>

<h2>
Memproses Import...
</h2>


<p>
Queue Laravel akan berjalan disini.
</p>


<button
onClick={next}
>
Selesai
</button>


</div>

)

}


export default ImportProgress;