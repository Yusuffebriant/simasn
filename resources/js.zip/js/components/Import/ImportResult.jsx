function ImportResult(){


return (

<div>

<h2 className="text-2xl font-bold">

Import Selesai

</h2>


<p>
Berhasil : 0
</p>


<p>
Gagal : 0
</p>


</div>

)


}


export default ImportResult;