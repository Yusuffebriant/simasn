function RiwayatImport(){


return (

<div>


<h2 className="
text-2xl
font-bold
mb-5
">

Riwayat Import

</h2>



<table className="
border
w-full
bg-white
">


<thead>

<tr>

<th className="border p-3">
File
</th>


<th className="border p-3">
Periode
</th>


<th className="border p-3">
Status
</th>


</tr>

</thead>



<tbody>


<tr>


<td className="border p-3">

-

</td>


<td className="border p-3">

-

</td>


<td className="border p-3">

Belum ada

</td>


</tr>


</tbody>


</table>


</div>

);


}


export default RiwayatImport;