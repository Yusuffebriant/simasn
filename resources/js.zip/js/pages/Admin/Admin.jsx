import Sidebar from "../../components/Sidebar";
import ImportData from "./ImportData";

export default function Admin(){

return(

<div className="flex min-h-screen bg-gray-100">


    <Sidebar/>


    <main className="
        flex-1
        p-8
        overflow-x-auto
    ">


        <h1 className="
            text-4xl
            font-bold
            mb-8
        ">
            Admin
        </h1>


        <ImportData/>


    </main>


</div>


)

}